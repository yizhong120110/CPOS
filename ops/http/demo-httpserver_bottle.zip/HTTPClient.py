# -*- coding: utf-8 -*-
"""
    HTTPClient
    调用方式：
        1、python34 HHTPClient.py
"""

import random
from http.client import HTTPConnection
from contextlib import contextmanager
from urllib.parse import urlencode


@contextmanager
def connection(**kwds):
    """
        用在with语句中，用于提供连接对象。
        kwds:用于指定host,port,timeout参数的值
        用法:
            with connection(**kwds) as con:
            ...
    """
    con = None
    try:
        con = HTTPConnection(**kwds)
        yield con
    finally:
        if con:
            con.close()

                     
def sendRequest(con, url, params={}, method='GET', charset='utf-8', headers={} ):
    """
        指定参数发送HTTP请求
        参数:
            con: HTTP连接
            url: 访问地址 如：/index
            params: 参数 格式：name=jack&age=18,POST请求时该值为请求体
            method: GET or POST
            charset: server返回数据的编码格式
            headers: 请求头 字典格式
    """
    suburl = urlencode(params)
    url += "?_t="+str(random.random())
    args = {'method':method, 'headers':headers, 'url':url}
    if method == "POST":
        args['body'] = suburl 
    else:
        args['url'] += "&" +suburl
    con.request(**args)
    res = con.getresponse()
    return res.read().decode(charset)

    
if __name__ == "__main__":
    with connection(host='localhost', port=8080) as con:
        print(sendRequest(con, url='/index',method='GET', headers={'user_agent':'test'}, params = {'user1':'aaa', 'msg1':"你好"}))