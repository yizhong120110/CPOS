1、本服务最简单安装共三个文件 bottle.py ,app.py, url.py,实现了一个基于http的webserver，通过python34 app.py启动web服务，同时可以在url.py中定义所需功能
2、通过安装使用第三方模块mako可以获得更好的进行模板渲染


在nginx中配置https
1、安装ssl(任意目录）
    1)输入指令openssl genrsa -des3 -out server.key 1024
      按要求输入密码，密码验证
    2)输入指令openssl req -new -key server.key -out server.csr
      输入密码，然后输入一些基本信息（可以不填）
    3)输入指令openssl rsa -in server.key -out server_nopwd.key
      输入密码，writing RSA key
    4)输入指令openssl x509 -req -days 365 -in server.csr -signkey server_nopwd.key -out server.crt
      Getting Private key
2、在nginx.conf server中添加
    server {
        listen 5645;
        ssl on;
        ssl_certificate  /usr/local/nginx/conf/server.crt;          #刚才安装ssl的目录
        ssl_certificate_key  /usr/local/nginx/conf/server_nopwd.key;#刚才安装ssl的目录
        
        #ssl_session_timeout  5m;                  #设置客户端能够反复使用储存在缓存中的会话参数时间。
        #ssl_protocols  SSLv2 SSLv3 TLSv1;         #指定要开启的SSL协议。
        #ssl_ciphers  HIGH:!aNULL:!MD5;            #查看当前安装的OpenSSL版本所支持的密码列表
        #ssl_prefer_server_ciphers   on;           #依赖SSLv3和TLSv1协议的服务器密码将优先于客户端密码。
    }
注：修改nginx.conf，不要在同目录下备份此配置文件
以下若有疑问请参见FESB生产环境部署.xlsx-webservice环境搭建-3、uwsgi与nginx配置   以及该sheet页最后的uwsgi参数说明
启动nginx，nginx -c /home/tsgl/apps/nginx/conf/nginx.conf
启动uwsgi, uwsgi --socket=127.0.0.1:5642 --callable=wsgi_application --file=/home/zhtsyw_init/conf/helloworld.py
使用https访问即可

