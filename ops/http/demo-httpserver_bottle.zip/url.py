# -*- coding: utf-8 -*-
""" 尚捷科技 """
"""
    本脚本为view层，定义一个函数，注册访问路径，并返回响应内容
    例如：
    @route('/index')                # 访问路径
    def sjkfdemo_index():           # 函数名
        content = {}                # 渲染模板所需的数据
        return d_lookup.get_template('index.html').render_unicode(**content) # 渲染模板返回响应内容
         
"""
import os, traceback
from urllib.parse import urlencode, quote
from bottle import route ,static_file ,redirect ,request
from mako.lookup import TemplateLookup
from mako.template import Template

STATIC_DIR = os.path.join(os.path.split(__file__)[0], "static")
d_lookup = TemplateLookup(os.path.join(os.path.split(__file__)[0], "tpl"))

# 静态文件前应该添加的修饰
APP_STATIC_EXPOSE = "/static"

@route('/') 
def sjkfdemo_root():
    return redirect('/index')

@route('/index') 
def sjkfdemo_index():
    content = {}
    return d_lookup.get_template('index.html').render_unicode(**content)

# 这个不用每个app处理一次，应该提取出来 todo
@route('/static/<filepath:path>') 
def server_static(filepath):
    print(filepath)
    return static_file(filepath, root=STATIC_DIR)

# 重定向输出静态文件
@route('/caihong') 
def sjkfdemo_image1():
    return redirect('/static/images/'+quote('圆形彩虹')+'.jpg')


######################## 不需要使用mako格式时，直接return即可 ###################

# 输出弹出框
@route('/alert1') 
def sjkfdemo_alert2():
    return """<script>alert('hello world')</script>"""

# 实现页面跳转
@route('/script1') 
def sjkfdemo_script1():
    return """<script>window.location='http://www.baidu.com';</script>"""

# 实现页面跳转
@route('/script2') 
def sjkfdemo_script2():
    return """<script>window.location='/caihong';</script>"""


# 实现页面跳转 也可以
@route('/script3') 
def sjkfdemo_script3():
    return """<script>window.location='http://www.baidu.com';</script>"""

# mako模板
@route('/mako1_1') 
def sjkfdemo_mako1_1():
    return "%(hello)s"%{'hello':'测试_mako1'}

# mako模板
@route('/mako1') 
def sjkfdemo_mako1():
    return Template("${hello}").render_unicode(**{'hello':'测试_mako1'})
####################################################################################################

######################## 使用文件方式的mako模板时,请使用以下方式 ###################
# mako模板
@route('/mako2') 
def sjkfdemo_mako2():
    return d_lookup.get_template("testmako/mako2.html").render_unicode(**{'hello':'测试_mako2'})


# mako模板 展示静态文件
@route('/mako3') 
def sjkfdemo_mako3():
    content = {'hello':'测试_mako3' ,'APP_STATIC_EXPOSE':APP_STATIC_EXPOSE}
    return d_lookup.get_template("testmako/mako3.html").render_unicode(**content)
####################################################################################################


######################## json的相关测试 ###################
# json 方式页面
@route('/json1') 
def sjkfdemo_json1():
    content = {'hello':'测试_json1' ,'APP_STATIC_EXPOSE':APP_STATIC_EXPOSE }
    return d_lookup.get_template("json.html").render_unicode(**content)


# json 方式返回数据
@route('/json2', method='POST') 
def sjkfdemo_json2():
    # 使用这种方式可以取得unicode字符，request.POST.get('testkey','')方式不可以
    getrs = request.POST.testkey
    return {'hello':'测试_json[%s]'%(getrs)}
####################################################################################################


######################## post\get的相关测试 ###################
# form数据提交，展示页面
@route('/form_show') 
def sjkfdemo_form_show():
    content = {}
    # 这种方式是支持unicode字符参数传递的，后面一种不支持unicode字符参数request.GET.get('user1','')
    content['user1'] = request.GET.user1
    content['user2'] = request.GET.user2
    content['msg1'] = request.GET.msg1
    content['msg2'] = request.GET.msg2
    content['msg3'] = request.GET.msg3
    content['dbtype'] = request.GET.dbtype
    content['ywmc'] = request.GET.ywmc
    content['msg4'] = request.GET.msg4
    # request.GET.aaa 不存在的时候返回空串
    #print('8888888888888888888',type(request.GET.aaaaaaa))
    return d_lookup.get_template("form.html").render_unicode(**content)


# form数据提交，post方式
@route('/form_post', method='POST') 
def sjkfdemo_form_post():
    user1 = request.forms.user1
    passwd1 = request.forms.passwd1
    #print('-------form_post----------' ,user1 ,passwd1)
    msg1 = ''
    if user1 and passwd1 and user1 == passwd1:
        msg1 = '欢迎你，%s'%(user1)
    else:
        msg1 = '用户名密码需要一致'
    tip = urlencode({'user1':user1,'msg1':msg1})
    return redirect( '/form_show?%s' % tip )
    
# form数据提交，post方式
@route('/form_post1', method='POST') 
def sjkfdemo_form_post():
    user1 = request.forms.user1
    passwd1 = request.forms.passwd1
    #print('-------form_post----------' ,user1 ,passwd1)
    msg1 = ''
    if user1 and passwd1 and user1 == passwd1:
        msg1 = '欢迎你，%s'%(user1)
    else:
        msg1 = '用户名密码需要一致'
    tip = urlencode({'user1':user1,'msg1':msg1})
    return "hello %s,%s" % (user1, msg1)


# form数据提交，form_get方式
@route('/form_get') 
def sjkfdemo_form_get():
    user2 = request.GET.user2
    passwd2 = request.GET.passwd2
    print('--------form_get---------' ,user2 ,passwd2)
    msg2 = ''
    if user2 and passwd2 and user2 == passwd2:
        msg2 = '欢迎你，%s'%(user2)
    else:
        msg2 = '用户名密码需要一致'
    tip = urlencode({'user2':user2,'msg2':msg2})
    return redirect( '/form_show?%s' % tip )


# form数据提交，file文件测试
@route('/form_file', method='POST') 
def sjkfdemo_form_file():
    fileup = request.files.get('fileup')
    # 有两个属性raw_filename能提供unicode文件名，filename不能
#    print(repr(fileup) ,'-------',dir(fileup),'------',fileup.filename,'------',fileup.raw_filename)
    name, ext = os.path.splitext(fileup.raw_filename)
    if ext not in ('.txt','.png','.jpg','.jpeg'):
        return "只允许'.txt','.png','.jpg','.jpeg'"
    elif ext in ('.txt'):
        # 文件内容 可以使用fileup.file.getvalue()方式直接操作，也可以使用fileup.file.save(save_path)先保存再处理
        return fileup.file.getvalue().decode('gbk').encode('utf8')
    return redirect( '/form_show?msg3=%s' % ( name ) )

#####################################################################################################
