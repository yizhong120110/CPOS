# -*- coding: utf-8 -*-
""" 尚捷科技
    本脚本用于启动web服务，使用python34 app.py 启动服务
    登录http://localhost:8080/进行访问
        可以拓展业务功能
        1.修改url.py，增加一个业务
        2.编写一个mako支持的html放在tpl下
        3.直接访问定义在url中的uri即可
 """

import sys ,os
ROOT = os.path.abspath( os.path.split( __file__ )[0] )
sys.path.append( ROOT )

from bottle import run ,debug ,default_app
import url


app = default_app()
app_debug = False

# 是否在调试状态下
debug(app_debug)
if __name__ == "__main__":
    # 启动服务
    run(app=app ,host='0.0.0.0', port=8080 ,reloader=True)
